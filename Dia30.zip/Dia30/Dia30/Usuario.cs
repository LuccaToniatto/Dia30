﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Dia30
{
    class Usuario
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public string login { get; set; }
        public string senha { get; set; }
        public List<Usuario> listaUsuarios()
        {
            List<Usuario> li = new List<Usuario>();
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM usuario";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Usuario u = new Usuario();
                u.Id = (int)dr["Id"];
                u.nome = dr["nome"].ToString();
                u.login = dr["login"].ToString();
                u.senha = "******";
                li.Add(u);
            }
            return li;
        }

        public void Inserir(string nome, string login, string senha)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO usuario(nome,login,senha) VALUES ('" + nome + "','" + login + "','" + senha + "')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            Connect.FecharConexao();
        }

        public void Localiza(int id)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM usuario WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                nome = dr["nome"].ToString();
                login = dr["login"].ToString();
                senha = dr["senha"].ToString();
            }
        }

        public void Atualizar(int id, string nome, string login, string senha)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "UPDATE usuario SET nome='" + nome + "',login='" + login + "',senha='" + senha + "' WHERE Id = '" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            Connect.FecharConexao();
        }

        public void Exclui(int id)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "DELETE FROM usuario WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            Connect.FecharConexao();
        }
    }
}
