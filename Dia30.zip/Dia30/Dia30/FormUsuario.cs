﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;

namespace Dia30
{
    public partial class FormUsuario : Form
    {
        public FormUsuario()
        {
            InitializeComponent();
        }

        private void FormUsuario_Load(object sender, EventArgs e)
        {
            Usuario usu = new Usuario();
            List<Usuario> usuarios = usu.listaUsuarios();
            dgvUsuario.DataSource = usuarios;
        }

        private void btnLocalizar_Click_1(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtid.Text.Trim());
                Usuario usuario = new Usuario();
                usuario.Localiza(id);
                txtnome.Text = usuario.nome;
                txtlogin.Text = usuario.login;
                txtsenha.Text = usuario.senha;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnCadastrar_Click_1(object sender, EventArgs e)
        {
            try
            {
                Usuario usuario = new Usuario();
                usuario.Inserir(txtnome.Text, txtlogin.Text, txtsenha.Text);
                MessageBox.Show("Usuário cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Usuario> usu = usuario.listaUsuarios();
                dgvUsuario.DataSource = usu;
                txtnome.Text = "";
                txtlogin.Text = "";
                txtsenha.Text = "";
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click_1(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtid.Text.Trim());
                Usuario usuario = new Usuario();
                usuario.Atualizar(id, txtnome.Text, txtlogin.Text, txtsenha.Text);
                MessageBox.Show("Usuário atualizado com sucesso!", "Edição", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Usuario> usu = usuario.listaUsuarios();
                dgvUsuario.DataSource = usu;
                txtid.Text = "";
                txtnome.Text = "";
                txtlogin.Text = "";
                txtsenha.Text = "";
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtid.Text.Trim());
                Usuario usuario = new Usuario();
                usuario.Exclui(id);
                MessageBox.Show("Usuário excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Usuario> usu = usuario.listaUsuarios();
                dgvUsuario.DataSource = usu;
                txtid.Text = "";
                txtnome.Text = "";
                txtlogin.Text = "";
                txtsenha.Text = "";
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLimpaCampos_Click_1(object sender, EventArgs e)
        {
            txtid.Text = "";
            txtnome.Text = "";
            txtlogin.Text = "";
            txtsenha.Text = "";
        }

        private void btnSair_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormUsuario_Load_1(object sender, EventArgs e)
        {
            Usuario usu = new Usuario();
            List<Usuario> usuarios = usu.listaUsuarios();
            dgvUsuario.DataSource = usuarios;
        }
    }
}
