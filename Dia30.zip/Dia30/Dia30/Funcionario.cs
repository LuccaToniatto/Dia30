﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Dia30
{
    class Funcionario
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public int idade { get; set; }
        public string endereco { get; set; }
        public int salario { get; set; }
        public string cargo { get; set; }
        public string setor { get; set; }
        //public string gerente { get; set; }

        public List<Funcionario> listafuncionarios()
        {
            List<Funcionario> li = new List<Funcionario>();
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM funcionario";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Funcionario f = new Funcionario();
                f.Id = (int)dr["Id"];
                f.nome = dr["nome"].ToString();
                f.idade = (int)dr["idade"];
                f.endereco = dr["endereco"].ToString();
                f.salario = (int)dr["salario"];
                f.cargo = dr["cargo"].ToString();
                f.setor = dr["setor"].ToString();
                li.Add(f);
            }
            return li;
        }

        //public List<Funcionario> listasetor()
        //{
        //    List<Funcionario> li2 = new List<Funcionario>();
        //    SqlConnection con = Connect.ObterConexao();
        //    SqlCommand cmd2 = con.CreateCommand();
        //    cmd2.CommandText = "SELECT * FROM setor";
        //    cmd2.CommandType = CommandType.Text;
        //    SqlDataReader dr2 = cmd2.ExecuteReader();
        //    while (dr2.Read())
        //    {
        //        Funcionario f2 = new Funcionario();
        //        f2.Id = (int)dr2["Id"];
        //        f2.nome = dr2["nome"].ToString();
        //        f2.gerente = dr2["gerente"].ToString();
        //        li2.Add(f2);
        //    }
        //    return li2;
        //}

        public void Cadastrar(string nome, int idade, string endereco, int salario, string cargo, string setor) 
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO funcionario(nome,idade,endereco,salario,cargo,setor) VALUES ('"+nome+"','"+idade+"','"+endereco+"','"+salario+"','"+cargo+"','"+setor+"')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            Connect.FecharConexao();
        }

        public void Localizar(int Id)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM funcionario WHERE Id = '"+Id+"'";
            cmd.ExecuteNonQuery();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Id = (int)dr["Id"];
                nome = dr["nome"].ToString();
                idade = (int)dr["idade"];
                endereco = dr["endereco"].ToString();
                salario = (int)dr["salario"];
                cargo = dr["cargo"].ToString();
            }
        }

        public void Atualizar(int Id,string nome, int idade, string endereco, int salario, string cargo, string setor)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "UPDATE funcionario SET nome ='"+ nome + "',idade = '" + idade + "',endereco = '" + endereco + "',salario = '" + salario + "', cargo ='" + cargo + "',setor = '"+setor+"' WHERE Id = '"+ +Id+"' ";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            Connect.FecharConexao();
        }

        public void Excluir(int Id)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "DELETE FROM funcionario WHERE Id = '" + Id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            Connect.FecharConexao();
        }
    }
}
