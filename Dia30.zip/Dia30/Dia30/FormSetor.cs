﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Dia30
{
    public partial class FormSetor : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\programas\\Dia30\\Dia30\\DbDia30.mdf;Integrated Security=True");


        public void CarregaCbxFuncionario()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            string fun = "SELECT * FROM funcionario ORDER BY nome";
            SqlCommand cmd = new SqlCommand(fun, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(fun, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "funcionario");
            cbxFuncionario.ValueMember = "id";
            cbxFuncionario.DisplayMember = "nome";
            cbxFuncionario.DataSource = ds.Tables["funcionario"];
            con.Close();
        }
        public FormSetor()
        {
            InitializeComponent();
        }


        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            Setor setor = new Setor();
            setor.Cadastrar(txtNome.Text, cbxFuncionario.Text);
            MessageBox.Show("Setor cadastrado com Sucesso!");
            Setor set = new Setor();
            List<Setor> setores = set.listasetor();
            dgvSetor.DataSource = setores;
            txtNome.Text = "";
            Setor settt = new Setor();
            List<Setor> setoress = settt.listasetor();
            dgvSetor.DataSource = setoress;
            Connect.FecharConexao();
        }

        private void FormSetor_Load(object sender, EventArgs e)
        {
            Setor set = new Setor();
            List<Setor> setores = set.listasetor();
            dgvSetor.DataSource = setores;
            CarregaCbxFuncionario();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {

                int id = Convert.ToInt32(txtId.Text.Trim());
                Setor setor = new Setor();
                setor.localizar(id);
                txtNome.Text = setor.nome;
                txtGerente.Text = setor.gerente;


            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text.Trim());
            Setor setor = new Setor();
            setor.Atualizar(id, txtNome.Text, txtGerente.Text);
            Setor set = new Setor();
            List<Setor> setores = set.listasetor();
            dgvSetor.DataSource = setores;
            txtId.Text = "";
            txtNome.Text = "";
            txtGerente.Text = "";
            MessageBox.Show("Setor Atualizado com Sucesso!");
            Connect.FecharConexao();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text.Trim());
            Setor setor = new Setor();
            setor.Excluir(id);
            Setor set = new Setor();
            List<Setor> setores = set.listasetor();
            dgvSetor.DataSource = setores;
            MessageBox.Show("Setor excluido com sucesso!");
            txtId.Text = "";
            txtNome.Text = "";
            txtGerente.Text = "";

        }
    }
}
