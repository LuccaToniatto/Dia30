﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Dia30
{
    public partial class FormFuncionarios : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\programas\\Dia30\\Dia30\\DbDia30.mdf;Integrated Security=True");

        public FormFuncionarios()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void CarregaCBXSetor()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            string fun = "SELECT * FROM setor ORDER BY nome";
            SqlCommand cmd = new SqlCommand(fun, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(fun, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "setor");
            cbxSetor.ValueMember = "id";
            cbxSetor.DisplayMember = "nome".Trim();
            cbxSetor.DataSource = ds.Tables["setor"];
            con.Close();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {

                int sala = Convert.ToInt32(txtSalario.Text);
                int ida = Convert.ToInt32(txtIdade.Text);
                string nome = txtNome.Text.Trim();
                Funcionario funcionario = new Funcionario();
                funcionario.Cadastrar(nome, ida, txtEndereco.Text, sala, txtCargo.Text, cbxSetor.Text);
                List<Funcionario> fun = funcionario.listafuncionarios();
                txtNome.Text = "";
                txtIdade.Text = "";
                txtEndereco.Text = "";
                txtSalario.Text = "";
                txtCargo.Text = "";
                MessageBox.Show("Funcionario Cadastrado com sucesso!");
                Funcionario funn = new Funcionario();
                List<Funcionario> funcionarios = funn.listafuncionarios();
                dgvFuncionario.DataSource = funcionarios;
                Connect.FecharConexao();

            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void FormFuncionarios_Load(object sender, EventArgs e)
        {
            Funcionario fun = new Funcionario();
            List<Funcionario> funcionarios = fun.listafuncionarios();
            dgvFuncionario.DataSource = funcionarios;
            CarregaCBXSetor();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {

                int id = Convert.ToInt32(txtId.Text.Trim());
                Funcionario funcionario = new Funcionario();
                funcionario.Localizar(id);
                txtNome.Text = funcionario.nome;
                txtIdade.Text = Convert.ToString(funcionario.idade);
                txtEndereco.Text = funcionario.endereco;
                txtSalario.Text = Convert.ToString(funcionario.salario);
                txtCargo.Text = funcionario.cargo;


            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text.Trim());
            int sala = Convert.ToInt32(txtSalario.Text.Trim());
            int ida = Convert.ToInt32(txtIdade.Text.Trim());
            Funcionario funcionario = new Funcionario();
            funcionario.Atualizar(id, txtNome.Text, ida, txtEndereco.Text, sala, txtCargo.Text,cbxSetor.DisplayMember);
            Funcionario fun = new Funcionario();
            List<Funcionario> funcionarios = fun.listafuncionarios();
            dgvFuncionario.DataSource = funcionarios;
            txtNome.Text = "";
            txtIdade.Text = "";
            txtEndereco.Text = "";
            txtSalario.Text = "";
            txtCargo.Text = "";
            MessageBox.Show("Funcionario Atualizado com Sucesso!");
            Connect.FecharConexao();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text.Trim());
            Funcionario funcionario = new Funcionario();
            funcionario.Excluir(id);
            Funcionario fun = new Funcionario();
            List<Funcionario> funcionarios = fun.listafuncionarios();
            dgvFuncionario.DataSource = funcionarios;
            MessageBox.Show("Cadastro de funcionario excluido com Sucesso!");
            Connect.FecharConexao();
        }
    }
}
