﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Dia30
{
    class Setor
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public string gerente { get; set; }

        public List<Setor> listasetor()
        {
            List<Setor> li = new List<Setor>();
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM setor";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Setor s = new Setor();
                s.Id = (int)dr["Id"];
                s.nome = dr["nome"].ToString();
                s.gerente = dr["gerente"].ToString();
                li.Add(s);
            }
            return li;
        }
        public void localizar(int Id)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM setor WHERE Id = '" + Id + "'";
            cmd.ExecuteNonQuery();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                nome = dr["nome"].ToString();
                gerente = dr["gerente"].ToString();

            }
        }


        public void Cadastrar(string nome, string gerente)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO setor(nome,gerente) VALUES ('" + nome + "','" + gerente + "')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            Connect.FecharConexao();


        }

        public void Atualizar(int Id, string nome, string gerente)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "UPDATE setor SET nome ='" + nome + "',gerente = '" + gerente + "' WHERE Id = '" + +Id + "' ";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            Connect.FecharConexao();
        }

        public void Excluir(int Id)
        {
            SqlConnection con = Connect.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "DELETE FROM setor WHERE Id = '" + Id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            Connect.FecharConexao();
        }
    }
}
