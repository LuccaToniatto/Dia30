﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dia30
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void pbxFuncionarios_Click(object sender, EventArgs e)
        {
            FormFuncionarios fo = new FormFuncionarios();
            fo.Show();
        }

        private void pbxSetor_Click(object sender, EventArgs e)
        {
            FormSetor se = new FormSetor();
            se.Show();
        }

        private void btnUsuario_Click(object sender, EventArgs e)
        {
            FormUsuario usu = new FormUsuario();
            usu.Show();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
